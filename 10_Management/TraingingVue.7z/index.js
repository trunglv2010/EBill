

Vue.component("add-product",{
	template: `
	<div class="add-product">
		<div class="add-product-header">
			Add a new product
		</div>
		<div class="add-product-body">
			<form class="form-inline" @submit.prevent="onSubmit">
				<div class="form-group">
					<label>ID</label>
					<input type="text" required="required" class="form-control ml-sm-2 mr-sm-4 my-2" v-model.string="id">
				</div>
				<div class="form-group">
					<label>Name</label>
					<input type="text" required="required" class="form-control ml-sm-2 mr-sm-4 my-2" v-model.string="name">
				</div>
				<div class="form-group">
					<label>Price</label>
					<input type="text" required="required" class="form-control ml-sm-2 mr-sm-4 my-2" v-model.string="price">
				</div>
				<div class="ml-auto text-right">
					<button type="submit" class="btn btn-primary my-2" >Add</button>
				</div>
			</form>
		</div>
	</div>
	`,
	data() {
		return {
			id: null,
			name: null,
			price: null
		}
	},
	methods: {
		onSubmit() {
			let product = {
				id: this.id,
				name: this.name,
				price: this.price
			}
			
			this.$emit('added-new-product',product);

			this.id = null
			this.name = null
			this.price = null
		}
	}
})

Vue.component("product-row",{
	props: {
		product: {
			id: String,
			name: String,
			price: String,
		},
		index: Number

	},
	template: `
	<div >
		<div class="row data-row " v-if="!isEditing">
			<div class="col-md-2">{{ product.id }}</div>
			<div class="col-md-4">{{ product.name }}</div>
			<div class="col-md-3">{{ product.price }}</div>
			<div class="col-md-3">
				<a href="#" class="icon"  @click="clickDelete(index)">
					<i class="fa fa-trash"></i>
				</a>
				<a href="#" class="icon" @click="clickEdit(); isEditing = true;">
					<i class="fa fa-pencil"></i>
				</a>
				<a href="#/product/tJpihcL8IkkdafFQBvKU" class="icon" @click="clickViewDetail(index)">
					<i class="fa fa-eye"></i>
				</a>
			</div>
		</div>
		
		<div class="row data-row " v-else>
				<div class="col-md-2"><input type="text" v-model.string="displayData.id"></div>
				<div class="col-md-4"><input type="text" v-model.string="displayData.name" ></div>
				<div class="col-md-3"><input type="text" v-model.string="displayData.price" ></div>
				<div class="col-md-3">
					<a href="#" class="icon" @click="clickUpdate(index); isEditing = false;">
						<i class="fa fa-check"></i>
					</a>
					<a href="#" class="icon" @click="isEditing = false;">
						<i class="fa fa-ban"></i>
					</a>
				</div>
		</div>	
	</div>
	`,
	data() { 		
		return {
			isEditing: false,
			displayData: {
			}
		}
	},
	methods: {
		clickDelete(index) {
			this.$emit("delete-product", index);
		},
		clickEdit() {
			this.displayData = Object.assign({}, this.product);
		},
		clickUpdate(index) {
			this.$emit("update-product", this.displayData, index);
		},
		clickViewDetail(index) {
			this.$emit("view-product", index);
		}
	}
})

var app = new Vue({
	el: '#app',
	data: {
		productList: [
		{ id: 1, name: "Minh", price: 1000 },
		{ id: 2, name: "Beo", price: 2000 },
		{ id: 3, name: "AAA", price: 3000 },
		],
		productDetail: {
			id: null,
			name: null,
			price: null
		}
	},
	methods: {
		addProduct(product) {
			this.productList.push(product);
		},
		deleteProduct(index) {
			this.productList.splice(index, 1);
		},
		updateProduct(product,index) {
			this.productList.splice(index, 1, product);
		},
		viewProduct(index) {
			this.productDetail = Object.assign({}, this.productList[index]);
			showProductDetail();
		}
	}
})

$( document ).ready(function() {
	$(".product-detail").hide();
})

function showProductDetail() {
	$(".product-detail").show();
	$(".product-list").hide();
}

function showProductList() {
	$(".product-detail").hide();
	$(".product-list").show();
};